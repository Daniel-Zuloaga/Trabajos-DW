function cambiarTamano(){
    var parrafo = document.getElementById('parangaricutirimicuaro');
    parrafo.style.fontSize = '100px'
}
function cambiarColor(){
    var parrafo = document.getElementById('parangaricutirimicuaro');
    parrafo.style.color = 'green';
}